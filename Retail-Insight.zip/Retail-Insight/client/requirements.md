## Packages
recharts | Dashboard charts for sales and profit analysis
date-fns | Date formatting for reports and receipts
framer-motion | Smooth transitions for modals and page entries

## Notes
- Using Replit Auth for authentication
- FIFO logic is handled on backend, frontend sends simple sales data
- Dashboard uses Recharts for visual analytics
- POS interface needs high contrast and large touch targets

import { ShoppingCart } from "lucide-react";
import { type Product, type Variant } from "@shared/schema";

interface ProductCardProps {
  product: Product & { variants: Variant[] };
  onAddToCart: (variant: Variant) => void;
}

export function ProductCard({ product, onAddToCart }: ProductCardProps) {
  // Simple logic to find the main variant (usually the first one)
  const defaultVariant = product.variants[0];
  const hasVariants = product.variants.length > 0;
  
  // Calculate total stock across all variants if we had stock info (simplified here)
  const minPrice = hasVariants 
    ? Math.min(...product.variants.map(v => Number(v.price))) 
    : 0;

  return (
    <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden hover:shadow-md hover:border-primary/20 transition-all duration-300 group flex flex-col h-full">
      <div className="relative aspect-square bg-muted">
        {product.imageUrl ? (
          <img 
            src={product.imageUrl} 
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-secondary text-muted-foreground">
            No Image
          </div>
        )}
        
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
          <button 
            disabled={!hasVariants}
            onClick={() => defaultVariant && onAddToCart(defaultVariant)}
            className="w-full bg-primary hover:bg-primary/90 text-white font-medium py-2 rounded-lg shadow-lg active:scale-95 transition-all flex items-center justify-center gap-2"
          >
            <ShoppingCart className="w-4 h-4" />
            Add to Cart
          </button>
        </div>
      </div>
      
      <div className="p-4 flex flex-col flex-1">
        <h3 className="font-semibold text-foreground truncate" title={product.name}>
          {product.name}
        </h3>
        <p className="text-sm text-muted-foreground truncate mb-3">
          {product.category} • {product.brand || 'No Brand'}
        </p>
        
        <div className="mt-auto flex items-center justify-between">
          <span className="font-display font-bold text-lg text-primary">
            ${minPrice.toFixed(2)}
          </span>
          <div className="flex gap-1">
            {product.variants.length > 1 && (
              <span className="text-xs bg-secondary text-secondary-foreground px-2 py-1 rounded-md">
                {product.variants.length} Options
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

import { ReactNode } from "react";
import { ArrowUpRight, ArrowDownRight } from "lucide-react";

interface StatCardProps {
  title: string;
  value: string;
  trend?: {
    value: number;
    label: string;
  };
  icon: ReactNode;
  color?: "primary" | "accent" | "green" | "orange";
}

export function StatCard({ title, value, trend, icon, color = "primary" }: StatCardProps) {
  const colorMap = {
    primary: "bg-blue-50 text-blue-600",
    accent: "bg-purple-50 text-purple-600",
    green: "bg-emerald-50 text-emerald-600",
    orange: "bg-orange-50 text-orange-600",
  };

  return (
    <div className="bg-card rounded-xl p-6 border border-border/50 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <h3 className="text-2xl font-bold mt-2 font-display text-foreground">{value}</h3>
          
          {trend && (
            <div className="flex items-center mt-2 gap-2">
              <span className={`flex items-center text-xs font-medium px-1.5 py-0.5 rounded ${
                trend.value >= 0 ? 'text-emerald-700 bg-emerald-100' : 'text-rose-700 bg-rose-100'
              }`}>
                {trend.value >= 0 ? <ArrowUpRight className="w-3 h-3 mr-1" /> : <ArrowDownRight className="w-3 h-3 mr-1" />}
                {Math.abs(trend.value)}%
              </span>
              <span className="text-xs text-muted-foreground">{trend.label}</span>
            </div>
          )}
        </div>
        <div className={`p-3 rounded-xl ${colorMap[color]}`}>
          {icon}
        </div>
      </div>
    </div>
  );
}

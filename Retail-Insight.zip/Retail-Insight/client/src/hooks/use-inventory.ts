import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type Batch } from "@shared/schema";
import { z } from "zod";

// Fetch inventory list
export function useInventory(location?: string) {
  return useQuery({
    queryKey: [api.inventory.list.path, location],
    queryFn: async () => {
      const url = location 
        ? `${api.inventory.list.path}?location=${location}` 
        : api.inventory.list.path;
      
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch inventory");
      return api.inventory.list.responses[200].parse(await res.json());
    },
  });
}

// Restock inventory
type RestockInput = z.infer<typeof api.inventory.restock.input>;
export function useRestock() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: RestockInput) => {
      const res = await fetch(api.inventory.restock.path, {
        method: api.inventory.restock.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to restock");
      }
      return api.inventory.restock.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.inventory.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.products.list.path] });
    },
  });
}

// Transfer inventory
type TransferInput = z.infer<typeof api.inventory.transfer.input>;
export function useTransferStock() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: TransferInput) => {
      const res = await fetch(api.inventory.transfer.path, {
        method: api.inventory.transfer.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to transfer stock");
      }
      return api.inventory.transfer.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.inventory.list.path] });
    },
  });
}

// Adjust inventory (spoilage/loss)
type AdjustInput = z.infer<typeof api.inventory.adjust.input>;
export function useAdjustStock() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: AdjustInput) => {
      const res = await fetch(api.inventory.adjust.path, {
        method: api.inventory.adjust.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to adjust stock");
      }
      return api.inventory.adjust.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.inventory.list.path] });
    },
  });
}

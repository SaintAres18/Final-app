import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { z } from "zod";

type CreateSaleInput = z.infer<typeof api.sales.create.input>;

export function useCreateSale() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: CreateSaleInput) => {
      const res = await fetch(api.sales.create.path, {
        method: api.sales.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to process sale");
      }
      return api.sales.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.sales.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.inventory.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.reports.dashboard.path] });
      queryClient.invalidateQueries({ queryKey: [api.reports.sales.path] });
    },
  });
}

export function useSalesList(params?: { startDate?: string; endDate?: string }) {
  return useQuery({
    queryKey: [api.sales.list.path, params],
    queryFn: async () => {
      const searchParams = new URLSearchParams();
      if (params?.startDate) searchParams.append("startDate", params.startDate);
      if (params?.endDate) searchParams.append("endDate", params.endDate);
      
      const url = `${api.sales.list.path}?${searchParams.toString()}`;
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch sales");
      return api.sales.list.responses[200].parse(await res.json());
    },
  });
}

export function useDashboardStats() {
  return useQuery({
    queryKey: [api.reports.dashboard.path],
    queryFn: async () => {
      const res = await fetch(api.reports.dashboard.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch stats");
      return api.reports.dashboard.responses[200].parse(await res.json());
    },
  });
}

export function useSalesChart(period: "day" | "week" | "month") {
  return useQuery({
    queryKey: [api.reports.sales.path, period],
    queryFn: async () => {
      const url = `${api.reports.sales.path}?period=${period}`;
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch chart data");
      return api.reports.sales.responses[200].parse(await res.json());
    },
  });
}

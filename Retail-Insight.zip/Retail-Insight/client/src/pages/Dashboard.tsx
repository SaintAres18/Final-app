import { Sidebar } from "@/components/Sidebar";
import { StatCard } from "@/components/StatCard";
import { useDashboardStats, useSalesChart } from "@/hooks/use-sales";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from "recharts";
import { DollarSign, Package, TrendingUp, AlertTriangle } from "lucide-react";

export default function Dashboard() {
  const { data: stats, isLoading } = useDashboardStats();
  const { data: salesData, isLoading: isChartLoading } = useSalesChart("week");

  return (
    <div className="flex min-h-screen bg-muted/20">
      <Sidebar />
      <main className="flex-1 ml-64 p-8">
        <header className="mb-8">
          <h1 className="text-3xl font-bold font-display text-foreground">Overview</h1>
          <p className="text-muted-foreground">Welcome back, here's what's happening with your store today.</p>
        </header>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-32 bg-card animate-pulse rounded-xl border border-border/50" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <StatCard 
              title="Total Sales" 
              value={`$${stats?.totalSales.toFixed(2) || "0.00"}`} 
              icon={<DollarSign className="w-6 h-6" />} 
              color="primary"
            />
            <StatCard 
              title="Net Profit" 
              value={`$${stats?.netProfit.toFixed(2) || "0.00"}`} 
              icon={<TrendingUp className="w-6 h-6" />} 
              color="green"
            />
            <StatCard 
              title="Low Stock Items" 
              value={stats?.lowStockCount.toString() || "0"} 
              icon={<AlertTriangle className="w-6 h-6" />} 
              color="orange"
            />
            <StatCard 
              title="Expiring Batches" 
              value={stats?.expiringCount.toString() || "0"} 
              icon={<Package className="w-6 h-6" />} 
              color="accent"
            />
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-card rounded-xl border border-border p-6 shadow-sm">
            <h3 className="text-lg font-bold mb-6 font-display">Sales Revenue (Last 7 Days)</h3>
            <div className="h-[300px] w-full">
              {isChartLoading ? (
                <div className="w-full h-full bg-muted/20 animate-pulse rounded-lg" />
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={salesData || []}>
                    <defs>
                      <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                    <XAxis 
                      dataKey="date" 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{fill: 'hsl(var(--muted-foreground))', fontSize: 12}} 
                      dy={10}
                    />
                    <YAxis 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{fill: 'hsl(var(--muted-foreground))', fontSize: 12}} 
                      tickFormatter={(val) => `$${val}`}
                    />
                    <Tooltip 
                      contentStyle={{ backgroundColor: 'hsl(var(--popover))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                      itemStyle={{ color: 'hsl(var(--foreground))' }}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="amount" 
                      stroke="hsl(var(--primary))" 
                      strokeWidth={3}
                      fillOpacity={1} 
                      fill="url(#colorRevenue)" 
                    />
                  </AreaChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>

          <div className="bg-card rounded-xl border border-border p-6 shadow-sm">
            <h3 className="text-lg font-bold mb-6 font-display">Profit Margins</h3>
            <div className="h-[300px] w-full">
              {isChartLoading ? (
                <div className="w-full h-full bg-muted/20 animate-pulse rounded-lg" />
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={salesData || []}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                    <XAxis 
                      dataKey="date" 
                      hide
                    />
                    <Tooltip 
                      cursor={{fill: 'hsl(var(--muted))'}}
                      contentStyle={{ backgroundColor: 'hsl(var(--popover))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                    />
                    <Bar dataKey="profit" fill="hsl(var(--accent))" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>
            <div className="mt-4 text-center">
              <p className="text-sm text-muted-foreground">Daily profit analysis based on FIFO costing.</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

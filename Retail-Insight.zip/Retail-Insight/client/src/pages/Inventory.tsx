import { Sidebar } from "@/components/Sidebar";
import { useInventory, useRestock } from "@/hooks/use-inventory";
import { useState } from "react";
import { format } from "date-fns";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Plus, Archive, AlertTriangle, Search, Loader2 } from "lucide-react";
import { useProducts } from "@/hooks/use-products";
import { useToast } from "@/hooks/use-toast";

export default function Inventory() {
  const { data: inventory, isLoading } = useInventory();
  const { data: products } = useProducts();
  const [searchTerm, setSearchTerm] = useState("");
  const restockMutation = useRestock();
  const { toast } = useToast();
  
  // Restock Form State
  const [isRestockOpen, setIsRestockOpen] = useState(false);
  const [selectedVariantId, setSelectedVariantId] = useState<number | null>(null);
  const [restockQty, setRestockQty] = useState("");
  const [restockCost, setRestockCost] = useState("");
  const [batchNum, setBatchNum] = useState("");
  const [location, setLocation] = useState("Store");

  // Flatten products into variants for the select dropdown
  const allVariants = products?.flatMap(p => 
    p.variants.map(v => ({ 
      id: v.id, 
      label: `${p.name} - ${v.sku} (${v.name})` 
    }))
  ) || [];

  const handleRestock = async () => {
    if (!selectedVariantId || !restockQty || !restockCost) return;
    
    try {
      await restockMutation.mutateAsync({
        variantId: selectedVariantId,
        location,
        quantity: Number(restockQty),
        cost: Number(restockCost),
        batchNumber: batchNum || undefined,
      });
      
      toast({ title: "Stock Added", description: "Inventory updated successfully." });
      setIsRestockOpen(false);
      setRestockQty("");
      setRestockCost("");
      setBatchNum("");
      setSelectedVariantId(null);
    } catch (error: any) {
      toast({ 
        title: "Error", 
        description: error.message, 
        variant: "destructive" 
      });
    }
  };

  const filteredInventory = inventory?.filter(batch => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      batch.batchNumber?.toLowerCase().includes(term) ||
      batch.location.toLowerCase().includes(term)
    );
  });

  return (
    <div className="flex min-h-screen bg-muted/20">
      <Sidebar />
      <main className="flex-1 ml-64 p-8">
        <header className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold font-display text-foreground">Inventory</h1>
            <p className="text-muted-foreground">Manage stock batches, track expiry, and restock.</p>
          </div>
          
          <Dialog open={isRestockOpen} onOpenChange={setIsRestockOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2 shadow-lg shadow-primary/20">
                <Plus className="w-4 h-4" /> Restock Items
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Stock Batch</DialogTitle>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label>Product Variant</Label>
                  <select 
                    className="w-full p-2 rounded-md border bg-background"
                    onChange={(e) => setSelectedVariantId(Number(e.target.value))}
                    value={selectedVariantId || ""}
                  >
                    <option value="">Select a product...</option>
                    {allVariants.map(v => (
                      <option key={v.id} value={v.id}>{v.label}</option>
                    ))}
                  </select>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Quantity</Label>
                    <Input 
                      type="number" 
                      value={restockQty}
                      onChange={(e) => setRestockQty(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Cost Per Unit ($)</Label>
                    <Input 
                      type="number" 
                      value={restockCost}
                      onChange={(e) => setRestockCost(e.target.value)}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Batch Number</Label>
                    <Input 
                      value={batchNum}
                      onChange={(e) => setBatchNum(e.target.value)}
                      placeholder="Optional"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Location</Label>
                    <select 
                      className="w-full p-2 rounded-md border bg-background"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                    >
                      <option value="Store">Store</option>
                      <option value="Stockroom">Stockroom</option>
                    </select>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button onClick={handleRestock} disabled={restockMutation.isPending}>
                  {restockMutation.isPending ? "Saving..." : "Save Batch"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </header>

        <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
          <div className="p-4 border-b border-border flex items-center gap-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input 
                className="pl-10" 
                placeholder="Search batches..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <div className="flex items-center gap-1">
                <div className="w-3 h-3 rounded-full bg-yellow-100 border border-yellow-200" />
                <span>Low Stock</span>
              </div>
              <div className="flex items-center gap-1 ml-3">
                <div className="w-3 h-3 rounded-full bg-red-100 border border-red-200" />
                <span>Expired/Expiring</span>
              </div>
            </div>
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Batch #</TableHead>
                <TableHead>Variant ID</TableHead>
                <TableHead>Location</TableHead>
                <TableHead>Quantity</TableHead>
                <TableHead>Cost</TableHead>
                <TableHead>Received</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={7} className="h-24 text-center">
                    <div className="flex justify-center">
                      <Loader2 className="w-6 h-6 animate-spin text-primary" />
                    </div>
                  </TableCell>
                </TableRow>
              ) : filteredInventory?.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="h-32 text-center text-muted-foreground">
                    No inventory batches found.
                  </TableCell>
                </TableRow>
              ) : (
                filteredInventory?.map((batch) => {
                  const isLowStock = batch.quantity < 10; // Simplified threshold
                  return (
                    <TableRow key={batch.id} className={isLowStock ? "bg-yellow-50/50" : ""}>
                      <TableCell className="font-medium">
                        {batch.batchNumber || <span className="text-muted-foreground italic">N/A</span>}
                      </TableCell>
                      <TableCell>{batch.variantId}</TableCell>
                      <TableCell>
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-secondary text-secondary-foreground">
                          {batch.location}
                        </span>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {batch.quantity}
                          {isLowStock && <AlertTriangle className="w-4 h-4 text-yellow-500" />}
                        </div>
                      </TableCell>
                      <TableCell>${Number(batch.cost).toFixed(2)}</TableCell>
                      <TableCell>
                        {batch.createdAt && format(new Date(batch.createdAt), 'MMM d, yyyy')}
                      </TableCell>
                      <TableCell>
                        <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                          batch.quantity > 0 
                            ? "bg-green-100 text-green-700" 
                            : "bg-gray-100 text-gray-700"
                        }`}>
                          {batch.quantity > 0 ? "Active" : "Depleted"}
                        </span>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </div>
      </main>
    </div>
  );
}

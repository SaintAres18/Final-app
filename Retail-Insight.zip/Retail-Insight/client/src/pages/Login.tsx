import { Button } from "@/components/ui/button";

export default function Login() {
  return (
    <div className="flex min-h-screen bg-background">
      {/* Left Panel */}
      <div className="hidden lg:flex flex-col w-1/2 bg-primary p-12 text-primary-foreground relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary via-blue-600 to-indigo-700 opacity-90" />
        <div className="relative z-10 flex flex-col h-full justify-between">
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-lg bg-white text-primary flex items-center justify-center font-bold text-lg">
              S
            </span>
            <span className="font-display font-bold text-xl">StoreFlow</span>
          </div>
          
          <div>
            <h1 className="text-5xl font-display font-bold mb-6 leading-tight">
              Inventory management <br/>
              reimagined for retail.
            </h1>
            <p className="text-xl text-primary-foreground/80 max-w-lg">
              Streamline your operations with real-time tracking, FIFO costing, and powerful analytics.
            </p>
          </div>
          
          <div className="text-sm opacity-60">
            © 2024 StoreFlow Retail Systems
          </div>
        </div>
      </div>

      {/* Right Panel */}
      <div className="flex-1 flex flex-col items-center justify-center p-8">
        <div className="w-full max-w-sm space-y-8 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-display font-bold">Welcome back</h2>
            <p className="text-muted-foreground">Sign in to your dashboard</p>
          </div>

          <Button 
            className="w-full h-12 text-lg font-medium" 
            onClick={() => window.location.href = "/api/login"}
          >
            Sign in with Replit
          </Button>
          
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t border-border" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-background px-2 text-muted-foreground">
                Secure Authentication
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

import { Sidebar } from "@/components/Sidebar";
import { ProductCard } from "@/components/ProductCard";
import { useProducts } from "@/hooks/use-products";
import { useCreateSale } from "@/hooks/use-sales";
import { useState } from "react";
import { Search, Trash2, CreditCard, Banknote, ShoppingBag, Plus, Minus, Loader2 } from "lucide-react";
import { type Variant } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

type CartItem = {
  variantId: number;
  productId: number;
  productName: string;
  variantName: string;
  price: number;
  quantity: number;
};

export default function Pos() {
  const [searchTerm, setSearchTerm] = useState("");
  const { data: products, isLoading } = useProducts({ search: searchTerm });
  const [cart, setCart] = useState<CartItem[]>([]);
  const { toast } = useToast();
  const createSale = useCreateSale();
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  
  // Checkout Form State
  const [paymentMethod, setPaymentMethod] = useState("Cash");
  const [customerName, setCustomerName] = useState("");
  const [discount, setDiscount] = useState("0");

  const addToCart = (variant: Variant, product: any) => {
    setCart(prev => {
      const existing = prev.find(item => item.variantId === variant.id);
      if (existing) {
        return prev.map(item => 
          item.variantId === variant.id 
            ? { ...item, quantity: item.quantity + 1 } 
            : item
        );
      }
      return [...prev, {
        variantId: variant.id,
        productId: product.id,
        productName: product.name,
        variantName: `${variant.sku} - ${variant.name}`,
        price: Number(variant.price),
        quantity: 1
      }];
    });
  };

  const removeFromCart = (variantId: number) => {
    setCart(prev => prev.filter(item => item.variantId !== variantId));
  };

  const updateQuantity = (variantId: number, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.variantId === variantId) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const tax = subtotal * 0.0; // Assuming tax included or 0 for now
  const total = subtotal + tax;

  const handleCheckout = async () => {
    try {
      await createSale.mutateAsync({
        location: "Store",
        paymentMethod,
        customerName: customerName || undefined,
        discountAmount: Number(discount),
        items: cart.map(item => ({
          variantId: item.variantId,
          quantity: item.quantity,
          price: item.price
        }))
      });
      
      toast({
        title: "Sale Completed",
        description: `Receipt generated for $${total.toFixed(2)}`,
        variant: "default",
      });
      
      setCart([]);
      setIsCheckoutOpen(false);
      setCustomerName("");
      setDiscount("0");
    } catch (err: any) {
      toast({
        title: "Transaction Failed",
        description: err.message,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <div className="w-16 flex-shrink-0 z-50">
        <Sidebar />
      </div>

      {/* Main Content Area - Product Grid */}
      <div className="flex-1 ml-48 flex flex-col h-full border-r border-border">
        <div className="p-6 border-b border-border bg-card">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input 
              className="w-full pl-10 pr-4 py-3 bg-muted/50 border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
              placeholder="Search products by name or SKU..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 bg-muted/20">
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : (
            <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {products?.map((product) => (
                <ProductCard 
                  key={product.id} 
                  product={product} 
                  onAddToCart={(variant) => addToCart(variant, product)} 
                />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Right Sidebar - Cart */}
      <div className="w-[400px] bg-card flex flex-col h-full shadow-xl z-40">
        <div className="p-6 border-b border-border bg-primary/5">
          <h2 className="text-xl font-bold font-display flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-primary" />
            Current Order
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            {cart.length} items in cart
          </p>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-muted-foreground opacity-50">
              <ShoppingBag className="w-16 h-16 mb-4" />
              <p>Your cart is empty</p>
            </div>
          ) : (
            cart.map((item) => (
              <div key={item.variantId} className="bg-background rounded-lg p-3 border border-border shadow-sm flex items-center gap-3">
                <div className="flex-1">
                  <h4 className="font-medium text-sm truncate">{item.productName}</h4>
                  <p className="text-xs text-muted-foreground truncate">{item.variantName}</p>
                  <p className="text-sm font-bold text-primary mt-1">${(item.price * item.quantity).toFixed(2)}</p>
                </div>
                
                <div className="flex flex-col items-center gap-2">
                  <div className="flex items-center gap-2 bg-muted rounded-md p-1">
                    <button 
                      onClick={() => updateQuantity(item.variantId, -1)}
                      className="w-6 h-6 flex items-center justify-center rounded hover:bg-white shadow-sm transition-colors"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="text-sm font-medium w-6 text-center">{item.quantity}</span>
                    <button 
                      onClick={() => updateQuantity(item.variantId, 1)}
                      className="w-6 h-6 flex items-center justify-center rounded hover:bg-white shadow-sm transition-colors"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>
                  <button 
                    onClick={() => removeFromCart(item.variantId)}
                    className="text-destructive hover:text-destructive/80 text-xs flex items-center gap-1"
                  >
                    <Trash2 className="w-3 h-3" /> Remove
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="p-6 border-t border-border bg-muted/30 space-y-4">
          <div className="space-y-2 text-sm">
            <div className="flex justify-between text-muted-foreground">
              <span>Subtotal</span>
              <span>${subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-muted-foreground">
              <span>Tax (0%)</span>
              <span>${tax.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-lg font-bold pt-2 border-t border-border">
              <span>Total</span>
              <span>${total.toFixed(2)}</span>
            </div>
          </div>

          <Dialog open={isCheckoutOpen} onOpenChange={setIsCheckoutOpen}>
            <DialogTrigger asChild>
              <Button 
                className="w-full h-12 text-lg font-bold shadow-lg shadow-primary/20" 
                disabled={cart.length === 0}
              >
                Proceed to Checkout
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Complete Sale</DialogTitle>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="payment" className="text-right">
                    Payment
                  </Label>
                  <select 
                    id="payment"
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="col-span-3 flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    <option value="Cash">Cash</option>
                    <option value="Credit Card">Credit Card</option>
                    <option value="GCash">GCash</option>
                  </select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="customer" className="text-right">
                    Customer
                  </Label>
                  <Input
                    id="customer"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="col-span-3"
                    placeholder="Optional"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="discount" className="text-right">
                    Discount
                  </Label>
                  <Input
                    id="discount"
                    type="number"
                    value={discount}
                    onChange={(e) => setDiscount(e.target.value)}
                    className="col-span-3"
                    min="0"
                  />
                </div>
                
                <div className="mt-4 p-4 bg-muted/50 rounded-lg text-center">
                  <span className="block text-sm text-muted-foreground">Amount Due</span>
                  <span className="block text-3xl font-bold font-display text-primary">
                    ${(total - Number(discount)).toFixed(2)}
                  </span>
                </div>
              </div>
              <DialogFooter>
                <Button 
                  onClick={handleCheckout} 
                  disabled={createSale.isPending}
                  className="w-full h-12 text-lg"
                >
                  {createSale.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> 
                      Processing...
                    </>
                  ) : (
                    "Confirm Payment"
                  )}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </div>
  );
}

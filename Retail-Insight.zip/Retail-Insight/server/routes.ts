import type { Express } from "express";
import type { Server } from "http";
import { setupAuth, registerAuthRoutes } from "./replit_integrations/auth";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

async function seedDatabase() {
  const existingProducts = await storage.getProducts();
  if (existingProducts.length === 0) {
    console.log("Seeding database...");
    
    // 1. Create Perfume
    await storage.createProduct({
        name: "Vanilla Dream Perfume",
        description: "Sweet vanilla scent, long lasting.",
        category: "Perfumes",
        brand: "LuxeScent",
        supplier: "Perfume Supplier A",
        imageUrl: "https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&q=80&w=1000",
        variants: [
            {
                sku: "PERF-VAN-50ML",
                name: "Vanilla Dream 50ml",
                size: "50ml",
                price: 500,
                stockLowAlert: 5,
                initialStock: [
                    { location: "Store", quantity: 10, cost: 200, batchNumber: "B001", expirationDate: "2025-12-31" },
                    { location: "Stockroom", quantity: 50, cost: 190, batchNumber: "B002", expirationDate: "2026-06-30" }
                ]
            },
            {
                sku: "PERF-VAN-100ML",
                name: "Vanilla Dream 100ml",
                size: "100ml",
                price: 900,
                stockLowAlert: 3,
                initialStock: [
                     { location: "Store", quantity: 5, cost: 350, batchNumber: "B003" }
                ]
            }
        ]
    });

    // 2. Create Lotion
    await storage.createProduct({
        name: "Silky Smooth Lotion",
        description: "Hydrating lotion for dry skin.",
        category: "Lotions",
        brand: "GlowSkin",
        supplier: "Beauty Corp",
        imageUrl: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&q=80&w=1000",
        variants: [
            {
                sku: "LOT-SILK-250ML",
                name: "Silky Smooth 250ml",
                price: 250,
                initialStock: [
                    { location: "Store", quantity: 20, cost: 100, batchNumber: "B004" }
                ]
            }
        ]
    });

    // 3. Create Chocolate
    await storage.createProduct({
        name: "Dark Chocolate Bar",
        description: "70% Cocoa",
        category: "Chocolates",
        brand: "ChocoDelight",
        supplier: "Sweet Treats Inc",
        imageUrl: "https://images.unsplash.com/photo-1511381971705-78e6378417c4?auto=format&fit=crop&q=80&w=1000",
        variants: [
            {
                sku: "CHOC-DARK-100G",
                name: "Dark Chocolate 100g",
                price: 150,
                initialStock: [
                    { location: "Store", quantity: 100, cost: 80, batchNumber: "B005", expirationDate: "2024-12-31" }
                ]
            }
        ]
    });

    console.log("Database seeded!");
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Auth Setup
  await setupAuth(app);
  registerAuthRoutes(app);

  // Seed Data
  await seedDatabase();

  // --- Products ---
  app.get(api.products.list.path, async (req, res) => {
    const filters = {
        search: req.query.search as string,
        category: req.query.category as string,
        brand: req.query.brand as string,
    };
    const products = await storage.getProducts(filters);
    res.json(products);
  });

  app.get(api.products.get.path, async (req, res) => {
    const product = await storage.getProduct(Number(req.params.id));
    if (!product) return res.status(404).json({ message: "Product not found" });
    res.json(product);
  });

  app.post(api.products.create.path, async (req, res) => {
    try {
        const input = api.products.create.input.parse(req.body);
        const product = await storage.createProduct(input);
        res.status(201).json(product);
    } catch (err) {
        if (err instanceof z.ZodError) {
             return res.status(400).json({ message: err.message });
        }
        res.status(500).json({ message: "Internal Server Error" });
    }
  });

  // --- Inventory ---
  app.get(api.inventory.list.path, async (req, res) => {
    const location = req.query.location as string;
    const batches = await storage.getBatches(location);
    res.json(batches);
  });

  app.post(api.inventory.restock.path, async (req, res) => {
    try {
        const input = api.inventory.restock.input.parse(req.body);
        const batch = await storage.restock(input);
        res.status(201).json(batch);
    } catch (err) {
        res.status(500).json({ message: err instanceof Error ? err.message : "Error" });
    }
  });

  app.post(api.inventory.transfer.path, async (req, res) => {
    try {
        const input = api.inventory.transfer.input.parse(req.body);
        const result = await storage.transferStock(input);
        res.json(result);
    } catch (err) {
        res.status(400).json({ message: err instanceof Error ? err.message : "Error" });
    }
  });

  // --- Sales ---
  app.post(api.sales.create.path, async (req, res) => {
    try {
        const input = api.sales.create.input.parse(req.body);
        const sale = await storage.createSale(input);
        res.status(201).json(sale);
    } catch (err) {
         res.status(400).json({ message: err instanceof Error ? err.message : "Error" });
    }
  });

  app.get(api.sales.list.path, async (req, res) => {
      const sales = await storage.getSales();
      res.json(sales);
  });

  app.get(api.reports.dashboard.path, async (req, res) => {
      const stats = await storage.getDashboardStats();
      res.json(stats);
  });

  return httpServer;
}

import { db } from "./db";
import { products, variants, batches, sales, saleItems, saleAllocations, stockMovements } from "@shared/schema";
import { eq, and, desc, sql, gte, lte, sum } from "drizzle-orm";
import type { CreateProductRequest, CreateSaleRequest } from "@shared/schema";

export interface IStorage {
  // Products
  getProducts(filters?: { search?: string; category?: string; brand?: string }): Promise<any[]>;
  getProduct(id: number): Promise<any | undefined>;
  createProduct(data: CreateProductRequest): Promise<any>;
  updateProduct(id: number, data: any): Promise<any>;
  deleteProduct(id: number): Promise<void>;

  // Inventory
  getBatches(location?: string): Promise<any[]>;
  restock(data: any): Promise<any>;
  transferStock(data: any): Promise<any>;
  adjustStock(data: any): Promise<any>;
  getVariantStock(variantId: number, location: string): Promise<number>;

  // Sales
  createSale(data: CreateSaleRequest): Promise<any>;
  getSales(startDate?: string, endDate?: string): Promise<any[]>;
  getDashboardStats(): Promise<any>;
  getSalesReport(period: "day" | "week" | "month"): Promise<any[]>;
}

export class DatabaseStorage implements IStorage {
  async getProducts(filters?: { search?: string; category?: string; brand?: string }) {
    const query = db.query.products.findMany({
      where: (products, { and, eq, ilike }) => {
        const conditions = [eq(products.isDeleted, false)];
        if (filters?.search) conditions.push(ilike(products.name, `%${filters.search}%`));
        if (filters?.category) conditions.push(eq(products.category, filters.category));
        if (filters?.brand) conditions.push(eq(products.brand, filters.brand));
        return and(...conditions);
      },
      with: {
        variants: {
          where: eq(variants.isDeleted, false),
          with: {
            batches: true // To calculate total stock
          }
        }
      },
      orderBy: desc(products.createdAt)
    });
    return await query;
  }

  async getProduct(id: number) {
    return await db.query.products.findFirst({
      where: eq(products.id, id),
      with: {
        variants: {
          where: eq(variants.isDeleted, false),
          with: {
            batches: true
          }
        }
      }
    });
  }

  async createProduct(data: CreateProductRequest) {
    return await db.transaction(async (tx) => {
      const [newProduct] = await tx.insert(products).values({
        name: data.name,
        description: data.description,
        category: data.category,
        brand: data.brand,
        supplier: data.supplier,
        imageUrl: data.imageUrl,
      }).returning();

      for (const v of data.variants) {
        const [newVariant] = await tx.insert(variants).values({
          productId: newProduct.id,
          sku: v.sku,
          name: v.name,
          size: v.size,
          color: v.color,
          price: v.price.toString(),
          stockLowAlert: v.stockLowAlert,
        }).returning();

        if (v.initialStock && v.initialStock.length > 0) {
          for (const stock of v.initialStock) {
            const [batch] = await tx.insert(batches).values({
              variantId: newVariant.id,
              location: stock.location,
              quantity: stock.quantity,
              originalQuantity: stock.quantity,
              cost: stock.cost.toString(),
              batchNumber: stock.batchNumber,
              expirationDate: stock.expirationDate,
              supplier: data.supplier,
            }).returning();

            await tx.insert(stockMovements).values({
              variantId: newVariant.id,
              batchId: batch.id,
              type: "RESTOCK",
              quantity: stock.quantity,
              toLocation: stock.location,
              reason: "Initial Stock",
            });
          }
        }
      }

      return newProduct;
    });
  }

  async updateProduct(id: number, data: any) {
    const [updated] = await db.update(products).set(data).where(eq(products.id, id)).returning();
    return updated;
  }

  async deleteProduct(id: number) {
    await db.update(products).set({ isDeleted: true }).where(eq(products.id, id));
  }

  // Inventory
  async getBatches(location?: string) {
    return await db.query.batches.findMany({
      where: location ? and(eq(batches.location, location), sql`${batches.quantity} > 0`) : sql`${batches.quantity} > 0`,
      with: {
        variant: {
          with: { product: true }
        }
      },
      orderBy: [batches.expirationDate, batches.createdAt] // FIFO Logic preference
    });
  }

  async restock(data: any) {
    return await db.transaction(async (tx) => {
      const [batch] = await tx.insert(batches).values({
        variantId: data.variantId,
        location: data.location,
        quantity: data.quantity,
        originalQuantity: data.quantity,
        cost: data.cost.toString(),
        batchNumber: data.batchNumber,
        expirationDate: data.expirationDate,
        supplier: data.supplier,
      }).returning();

      await tx.insert(stockMovements).values({
        variantId: data.variantId,
        batchId: batch.id,
        type: "RESTOCK",
        quantity: data.quantity,
        toLocation: data.location,
        reason: "Restock",
      });

      return batch;
    });
  }

  async transferStock(data: any) {
    // FIFO Transfer: Take from oldest batches in source location
    return await db.transaction(async (tx) => {
      let remainingToTransfer = data.quantity;
      const sourceBatches = await tx.query.batches.findMany({
        where: and(
          eq(batches.variantId, data.variantId),
          eq(batches.location, data.fromLocation),
          sql`${batches.quantity} > 0`
        ),
        orderBy: [batches.expirationDate, batches.createdAt]
      });

      let totalTransferred = 0;

      for (const batch of sourceBatches) {
        if (remainingToTransfer <= 0) break;

        const takeAmount = Math.min(batch.quantity, remainingToTransfer);
        
        // Decrement source batch
        await tx.update(batches)
          .set({ quantity: sql`${batches.quantity} - ${takeAmount}` })
          .where(eq(batches.id, batch.id));
        
        // Create new batch at destination (keeping original cost/expiry)
        await tx.insert(batches).values({
          variantId: batch.variantId,
          location: data.toLocation,
          quantity: takeAmount,
          originalQuantity: takeAmount, // It's a "new" batch in this location
          cost: batch.cost,
          batchNumber: batch.batchNumber,
          expirationDate: batch.expirationDate,
          supplier: batch.supplier,
        });

        // Log movement
        await tx.insert(stockMovements).values({
          variantId: data.variantId,
          batchId: batch.id,
          type: "TRANSFER",
          quantity: -takeAmount,
          fromLocation: data.fromLocation,
          toLocation: data.toLocation,
          reason: data.reason || "Stock Transfer",
        });

        remainingToTransfer -= takeAmount;
        totalTransferred += takeAmount;
      }

      if (remainingToTransfer > 0) {
        throw new Error(`Insufficient stock in ${data.fromLocation}. Could only transfer ${totalTransferred}.`);
      }

      return { success: true, movedQuantity: totalTransferred };
    });
  }

  async adjustStock(data: any) {
    return await db.transaction(async (tx) => {
      const [batch] = await tx.select().from(batches).where(eq(batches.id, data.batchId));
      if (!batch) throw new Error("Batch not found");

      const newQuantity = batch.quantity + data.quantityChange;
      if (newQuantity < 0) throw new Error("Adjustment results in negative stock");

      const [updatedBatch] = await tx.update(batches)
        .set({ quantity: newQuantity })
        .where(eq(batches.id, data.batchId))
        .returning();

      await tx.insert(stockMovements).values({
        variantId: batch.variantId,
        batchId: batch.id,
        type: "ADJUSTMENT",
        quantity: data.quantityChange,
        fromLocation: batch.location,
        reason: data.reason,
      });

      return updatedBatch;
    });
  }

  async getVariantStock(variantId: number, location: string) {
    const result = await db.select({ total: sum(batches.quantity) })
      .from(batches)
      .where(and(eq(batches.variantId, variantId), eq(batches.location, location)));
    return Number(result[0]?.total || 0);
  }

  // Sales (The Complex Part - FIFO)
  async createSale(data: CreateSaleRequest) {
    return await db.transaction(async (tx) => {
      // 1. Create Sale Record
      const [sale] = await tx.insert(sales).values({
        receiptNumber: `REC-${Date.now()}`,
        totalAmount: "0", // Calced below
        discountAmount: data.discountAmount?.toString() || "0",
        shippingFee: data.shippingFee?.toString() || "0",
        netAmount: "0", // Calced below
        paymentMethod: data.paymentMethod,
        shippingMethod: data.shippingMethod,
        customerName: data.customerName,
        location: data.location,
      }).returning();

      let grandTotal = 0;

      // 2. Process Items
      for (const item of items) {
        const variant = await tx.query.variants.findFirst({
          where: eq(variants.id, item.variantId),
          with: { product: true }
        });
        if (!variant) throw new Error(`Variant ${item.variantId} not found`);

        const lineTotal = item.quantity * Number(item.price);
        grandTotal += lineTotal;

        // Create Sale Item
        const [saleItem] = await tx.insert(saleItems).values({
          saleId: sale.id,
          variantId: item.variantId,
          quantity: item.quantity,
          unitPrice: item.price.toString(),
          subtotal: lineTotal.toString(),
          productName: variant.product.name,
          variantName: variant.name,
        }).returning();

        // 3. FIFO Allocation
        let remainingToDeduct = item.quantity;
        // Find batches for this variant in this location, oldest first
        const availableBatches = await tx.query.batches.findMany({
          where: and(
            eq(batches.variantId, item.variantId),
            eq(batches.location, data.location),
            sql`${batches.quantity} > 0`
          ),
          orderBy: [batches.expirationDate, batches.createdAt]
        });

        for (const batch of availableBatches) {
          if (remainingToDeduct <= 0) break;

          const take = Math.min(batch.quantity, remainingToDeduct);
          
          // Deduct from batch
          await tx.update(batches)
            .set({ quantity: sql`${batches.quantity} - ${take}` })
            .where(eq(batches.id, batch.id));

          // Record allocation (This locks in the cost for profit calc)
          await tx.insert(saleAllocations).values({
            saleItemId: saleItem.id,
            batchId: batch.id,
            quantity: take,
            costAtSale: batch.cost,
          });

          // Log movement
          await tx.insert(stockMovements).values({
            variantId: item.variantId,
            batchId: batch.id,
            type: "SALE",
            quantity: -take,
            fromLocation: data.location,
            referenceId: sale.id.toString(),
            reason: `Sale ${sale.receiptNumber}`,
          });

          remainingToDeduct -= take;
        }

        if (remainingToDeduct > 0) {
          throw new Error(`Insufficient stock for ${variant.name} in ${data.location}`);
        }
      }

      // Update Sale Totals
      const discount = Number(data.discountAmount || 0);
      const shipping = Number(data.shippingFee || 0);
      const net = grandTotal - discount + shipping;

      const [finalSale] = await tx.update(sales).set({
        totalAmount: grandTotal.toString(),
        netAmount: net.toString()
      }).where(eq(sales.id, sale.id)).returning();

      return finalSale;
    });
  }

  async getSales(startDate?: string, endDate?: string) {
    return await db.query.sales.findMany({
      orderBy: desc(sales.createdAt),
      with: { items: true }
    });
  }

  async getDashboardStats() {
    // This would be better with raw SQL for performance on large data, but Drizzle is fine for now
    const allSales = await db.select({
      net: sales.netAmount
    }).from(sales);

    const totalSales = allSales.reduce((acc, s) => acc + Number(s.net), 0);

    // Calculate profit: Net Sales - Total Cost of Goods Sold
    // COGS = sum(allocation.quantity * allocation.costAtSale)
    const allocations = await db.select().from(saleAllocations);
    const totalCOGS = allocations.reduce((acc, a) => acc + (a.quantity * Number(a.costAtSale)), 0);
    
    // Simplistic Net Profit (Revenue - COGS). Doesn't account for shipping/discounts perfectly in this simple math without more logic
    // Actually: Net Amount (Rev - Disc + Ship) - COGS. 
    // Wait, shipping is income or expense? Usually income from customer, but we pay courier. Let's assume neutral or income.
    // Profit = Net Sales - COGS.
    const netProfit = totalSales - totalCOGS;

    return {
      totalSales,
      netProfit,
      lowStockCount: 0, // TODO: Implement
      expiringCount: 0 // TODO: Implement
    };
  }
  
  async getSalesReport(period: "day" | "week" | "month") {
      // Placeholder for chart data
      return [];
  }
}

export const storage = new DatabaseStorage();

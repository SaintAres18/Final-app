import { z } from "zod";
import { insertProductSchema, insertVariantSchema, products, variants, batches, sales, stockMovements } from "./schema";

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

// Common response schemas
const productWithVariantsSchema = z.custom<typeof products.$inferSelect & { variants: typeof variants.$inferSelect[] }>();
const variantWithStockSchema = z.custom<typeof variants.$inferSelect & { stock: Record<string, number> }>();
const batchSchema = z.custom<typeof batches.$inferSelect>();
const saleSchema = z.custom<typeof sales.$inferSelect & { items: any[] }>();

export const api = {
  products: {
    list: {
      method: "GET" as const,
      path: "/api/products" as const,
      input: z.object({
        search: z.string().optional(),
        category: z.string().optional(),
        brand: z.string().optional(),
      }).optional(),
      responses: {
        200: z.array(productWithVariantsSchema),
      },
    },
    get: {
      method: "GET" as const,
      path: "/api/products/:id" as const,
      responses: {
        200: productWithVariantsSchema,
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: "POST" as const,
      path: "/api/products" as const,
      input: z.object({
        name: z.string(),
        description: z.string().optional(),
        category: z.string(),
        brand: z.string().optional(),
        supplier: z.string().optional(),
        imageUrl: z.string().optional(),
        variants: z.array(z.object({
          sku: z.string(),
          name: z.string(),
          size: z.string().optional(),
          color: z.string().optional(),
          price: z.number().or(z.string()), // Accept number or string (numeric)
          stockLowAlert: z.number().optional(),
          initialStock: z.array(z.object({
            location: z.string(),
            quantity: z.number(),
            cost: z.number().or(z.string()),
            batchNumber: z.string().optional(),
            expirationDate: z.string().optional(),
          })).optional(),
        })),
      }),
      responses: {
        201: productWithVariantsSchema,
        400: errorSchemas.validation,
      },
    },
    update: {
      method: "PUT" as const,
      path: "/api/products/:id" as const,
      input: insertProductSchema.partial(),
      responses: {
        200: z.custom<typeof products.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: "DELETE" as const,
      path: "/api/products/:id" as const,
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },
  inventory: {
    list: {
      method: "GET" as const,
      path: "/api/inventory" as const,
      input: z.object({
        location: z.string().optional(),
      }).optional(),
      responses: {
        200: z.array(batchSchema),
      },
    },
    restock: {
      method: "POST" as const,
      path: "/api/inventory/restock" as const,
      input: z.object({
        variantId: z.number(),
        location: z.string(),
        quantity: z.number().min(1),
        cost: z.number().or(z.string()),
        batchNumber: z.string().optional(),
        expirationDate: z.string().optional(), // ISO date string
        supplier: z.string().optional(),
      }),
      responses: {
        201: batchSchema,
        400: errorSchemas.validation,
      },
    },
    transfer: {
      method: "POST" as const,
      path: "/api/inventory/transfer" as const,
      input: z.object({
        variantId: z.number(),
        fromLocation: z.string(),
        toLocation: z.string(),
        quantity: z.number().min(1),
        reason: z.string().optional(),
      }),
      responses: {
        200: z.object({ success: z.boolean(), movedQuantity: z.number() }),
        400: errorSchemas.validation,
      },
    },
    adjust: {
      method: "POST" as const,
      path: "/api/inventory/adjust" as const,
      input: z.object({
        batchId: z.number(),
        quantityChange: z.number(), // Negative for loss/damage
        reason: z.string(),
      }),
      responses: {
        200: batchSchema,
        400: errorSchemas.validation,
      },
    },
  },
  sales: {
    create: {
      method: "POST" as const,
      path: "/api/sales" as const,
      input: z.object({
        location: z.string(),
        paymentMethod: z.string(),
        shippingMethod: z.string().optional(),
        shippingFee: z.number().or(z.string()).optional(),
        discountAmount: z.number().or(z.string()).optional(),
        customerName: z.string().optional(),
        items: z.array(z.object({
          variantId: z.number(),
          quantity: z.number().min(1),
          price: z.number().or(z.string()), // Unit price
        })),
      }),
      responses: {
        201: saleSchema,
        400: errorSchemas.validation,
      },
    },
    list: {
      method: "GET" as const,
      path: "/api/sales" as const,
      input: z.object({
        startDate: z.string().optional(),
        endDate: z.string().optional(),
      }).optional(),
      responses: {
        200: z.array(saleSchema),
      },
    },
  },
  reports: {
    dashboard: {
      method: "GET" as const,
      path: "/api/reports/dashboard" as const,
      responses: {
        200: z.object({
          totalSales: z.number(),
          netProfit: z.number(),
          lowStockCount: z.number(),
          expiringCount: z.number(),
        }),
      },
    },
    sales: {
      method: "GET" as const,
      path: "/api/reports/sales" as const,
      input: z.object({
        period: z.enum(["day", "week", "month"]),
      }),
      responses: {
        200: z.array(z.object({
          date: z.string(),
          amount: z.number(),
          profit: z.number(),
        })),
      },
    },
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      url = url.replace(`:${key}`, String(value));
    });
  }
  return url;
}

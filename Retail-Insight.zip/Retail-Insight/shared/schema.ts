import { pgTable, text, serial, integer, boolean, timestamp, numeric, date } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
export * from "./models/auth";

// --- Products & Variants ---

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category").notNull(),
  brand: text("brand"),
  supplier: text("supplier"),
  imageUrl: text("image_url"),
  isActive: boolean("is_active").default(true),
  isDeleted: boolean("is_deleted").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const variants = pgTable("variants", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").notNull(),
  sku: text("sku").notNull().unique(),
  name: text("name").notNull(), // e.g. "Small - Red"
  size: text("size"),
  color: text("color"),
  price: numeric("price").notNull(), // Selling Price
  stockLowAlert: integer("stock_low_alert").default(10),
  isDeleted: boolean("is_deleted").default(false),
});

export const productsRelations = relations(products, ({ many }) => ({
  variants: many(variants),
}));

export const variantsRelations = relations(variants, ({ one, many }) => ({
  product: one(products, {
    fields: [variants.productId],
    references: [products.id],
  }),
  batches: many(batches),
}));

// --- Inventory (FIFO) ---

export const batches = pgTable("batches", {
  id: serial("id").primaryKey(),
  variantId: integer("variant_id").notNull(),
  batchNumber: text("batch_number"),
  supplier: text("supplier"),
  cost: numeric("cost").notNull(), // Cost per unit for this batch
  quantity: integer("quantity").notNull(), // Current remaining quantity
  originalQuantity: integer("original_quantity").notNull(), // Initial quantity
  location: text("location").notNull(), // 'Store' | 'Stockroom'
  expirationDate: date("expiration_date"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const batchesRelations = relations(batches, ({ one }) => ({
  variant: one(variants, {
    fields: [batches.variantId],
    references: [variants.id],
  }),
}));

// --- Sales ---

export const sales = pgTable("sales", {
  id: serial("id").primaryKey(),
  receiptNumber: text("receipt_number").notNull().unique(),
  totalAmount: numeric("total_amount").notNull(), // Gross
  discountAmount: numeric("discount_amount").default("0"),
  shippingFee: numeric("shipping_fee").default("0"),
  netAmount: numeric("net_amount").notNull(), // Total - Discount + Shipping
  paymentMethod: text("payment_method").notNull(), // Cash, GCash, etc.
  shippingMethod: text("shipping_method"), // Lalamove, LBC, etc.
  customerName: text("customer_name"),
  location: text("location").notNull(), // 'Store' | 'Stockroom' (where sold from)
  createdAt: timestamp("created_at").defaultNow(),
});

// A sale item tracks which variant was sold.
// Note: To strictly track FIFO cost, we need to know exactly which batch provided the item.
// If a single line item (e.g. 5 soaps) is fulfilled by Batch A (2 left) and Batch B (3 left),
// we should strictly record two entries or have a separate allocations table.
// To keep it queryable, we will store the 'line item' as seen on receipt, but also
// a separate table `sale_allocations` linking to batches for strict FIFO costing.

export const saleItems = pgTable("sale_items", {
  id: serial("id").primaryKey(),
  saleId: integer("sale_id").notNull(),
  variantId: integer("variant_id").notNull(),
  quantity: integer("quantity").notNull(),
  unitPrice: numeric("unit_price").notNull(), // Price at moment of sale
  subtotal: numeric("subtotal").notNull(),
  productName: text("product_name").notNull(), // Snapshot
  variantName: text("variant_name").notNull(), // Snapshot
});

// Tracks strictly which batch a sold item came from, for precise profit calculation.
export const saleAllocations = pgTable("sale_allocations", {
  id: serial("id").primaryKey(),
  saleItemId: integer("sale_item_id").notNull(),
  batchId: integer("batch_id").notNull(),
  quantity: integer("quantity").notNull(),
  costAtSale: numeric("cost_at_sale").notNull(), // Snapshot of batch cost
});

export const salesRelations = relations(sales, ({ many }) => ({
  items: many(saleItems),
}));

export const saleItemsRelations = relations(saleItems, ({ one, many }) => ({
  sale: one(sales, {
    fields: [saleItems.saleId],
    references: [sales.id],
  }),
  allocations: many(saleAllocations),
}));

export const saleAllocationsRelations = relations(saleAllocations, ({ one }) => ({
  saleItem: one(saleItems, {
    fields: [saleAllocations.saleItemId],
    references: [saleItems.id],
  }),
  batch: one(batches, {
    fields: [saleAllocations.batchId],
    references: [batches.id],
  }),
}));

// --- Stock Movements / Audit ---

export const stockMovements = pgTable("stock_movements", {
  id: serial("id").primaryKey(),
  variantId: integer("variant_id").notNull(),
  batchId: integer("batch_id"), // Optional, if specific batch
  type: text("type").notNull(), // 'RESTOCK', 'SALE', 'TRANSFER', 'ADJUSTMENT', 'RETURN'
  quantity: integer("quantity").notNull(), // Positive or negative
  fromLocation: text("from_location"),
  toLocation: text("to_location"),
  reason: text("reason"),
  referenceId: text("reference_id"), // e.g. Sale ID
  createdAt: timestamp("created_at").defaultNow(),
});

// --- Zod Schemas ---

export const insertProductSchema = createInsertSchema(products).omit({ id: true, createdAt: true, isDeleted: true });
export const insertVariantSchema = createInsertSchema(variants).omit({ id: true, isDeleted: true });
export const insertBatchSchema = createInsertSchema(batches).omit({ id: true, createdAt: true, quantity: true }); // Quantity is handled via specialized input usually
export const insertSaleSchema = createInsertSchema(sales).omit({ id: true, createdAt: true, receiptNumber: true });

// Types
export type Product = typeof products.$inferSelect;
export type Variant = typeof variants.$inferSelect;
export type Batch = typeof batches.$inferSelect;
export type Sale = typeof sales.$inferSelect;
export type SaleItem = typeof saleItems.$inferSelect;
export type StockMovement = typeof stockMovements.$inferSelect;

export type CreateProductRequest = z.infer<typeof insertProductSchema> & {
  variants: (z.infer<typeof insertVariantSchema> & {
    initialStock?: {
      location: string;
      quantity: number;
      cost: string;
      batchNumber?: string;
      expirationDate?: string;
    }[]
  })[];
};

export type CreateSaleRequest = {
  items: {
    variantId: number;
    quantity: number;
    price: number; // Override allowed?
  }[];
  paymentMethod: string;
  shippingMethod?: string;
  shippingFee?: number;
  discountAmount?: number;
  customerName?: string;
  location: string;
};
